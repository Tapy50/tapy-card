var exchangeContact = document.getElementById("exchange-contact");
var backBtn = document.getElementById("backBtn");
var contactContainer = document.getElementById("contact-container");
var parentContainer = document.getElementById("parent-container");

exchangeContact.onclick = function () {
  contactContainer.style.display = "block";
  parentContainer.style.display = "none"
}

backBtn.onclick = function () {
  contactContainer.style.display = "none";
  parentContainer.style.display = "block"
}


/***************************************/
var timeInput = document.getElementById("time");
var hour = "06:00";
var hour = document.querySelectorAll("#hour");

for (var i=0 ; i<hour.length ; i++){

  hour[i].addEventListener("click",function(e){

    for (var i=0 ; i<hour.length ; i++){
      hour[i].classList.remove("active");
    }

      var element = e.target;
      element.classList.add('active');

      hour.value = element.innerText;
  })
}


/*******       All swiper      *********/
var swiper = new Swiper(".myAllSwiper", {
    speed: 1500,
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
    autoplay: {
        delay: 1000,
        disableOnInteraction: false,
      },
  });
  var swiper2 = new Swiper(".allSwiper", {
    autoplay: {
        delay: 1000,
        disableOnInteraction: false,
      },
    spaceBetween: 10,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    thumbs: {
      swiper: swiper,
    },
  });

/*******       rooms swiper      *********/
var swiper = new Swiper(".myRoomsSwiper", {
    speed: 1500,
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
    autoplay: {
        delay: 1000,

      },
  });
  var swiper2 = new Swiper(".roomsSwiper", {
    spaceBetween: 10,
    autoplay: {
        delay: 1000,
        disableOnInteraction: false,
      },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    thumbs: {
      swiper: swiper,
    },
  });

/*******       facilities swiper      *********/
var swiper = new Swiper(".myFacilitiesSwiper", {
    speed: 1500,
    spaceBetween: 10,
    slidesPerView: 4,
    freeMode: true,
    watchSlidesProgress: true,
    autoplay: {
        delay: 1000,

      },
  });
  var swiper2 = new Swiper(".facilitiesSwiper", {
    spaceBetween: 10,
    autoplay: {
        delay: 1000,
        disableOnInteraction: false,
      },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    thumbs: {
      swiper: swiper,
    },
  });

// end of:: wiper slides
